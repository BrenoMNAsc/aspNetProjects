﻿using Microsoft.AspNetCore.Mvc;
using webApi.bankService.breno.m.Models;

namespace webApi.bankService.breno.m.Controllers
{
    public class BankController : Controller
    {
        [Route("/")]
        public IActionResult Index()
        {
            return Content("<h1>Welcome to the Best Bank</h1>", "text/html");
        }

        [Route("/account-details")]
        public IActionResult AccountDetails()
        {
            BankAccount account = new BankAccount();
            account.accountNumber = 1001;
            account.currentBalance = 10.20f;
            account.accountName = "Test";
            return Json(account);
        }

        [Route("/account-statement")]
        public IActionResult AccountStaement() {
            return File("/accountStatement.pdf", "application/pdf");
        }

        [Route("/get-current-balance/{accountNumber}")]
        public IActionResult GetCurrentBalance(int? accountNumber) 
        {
            if (accountNumber == null)
            {
                return NotFound("Account Number should be supplied");
            }

            if(accountNumber != 1001)
            {
                return BadRequest("account should be 1001");
            }

            return Content("10.20", "text/plain");

            
        }


    }
}
