﻿namespace webApi.bankService.breno.m.Models
{
    public class BankAccount
    {
        public float? currentBalance { get; set; }
        public int? accountNumber { get; set; }
        public string? accountName { get; set; }

    }
}
